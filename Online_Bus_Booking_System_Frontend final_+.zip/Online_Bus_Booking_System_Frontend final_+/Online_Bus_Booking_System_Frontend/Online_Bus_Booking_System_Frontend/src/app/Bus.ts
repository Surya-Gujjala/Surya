export class Bus {
    busId: number;
    busName: string;
    noOfSeats: number;
    duration: string;
    typeOfBus: string;
    timeOfArrival: String;
    timeOfDeparture: String;
    fare: number;
    source: string;
    destination: string;
}