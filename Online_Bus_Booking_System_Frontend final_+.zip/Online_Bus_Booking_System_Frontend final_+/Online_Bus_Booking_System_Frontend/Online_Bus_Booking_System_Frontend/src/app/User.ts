export class User{
    userId:number
    firstName:string;
    lastName:string;
    email:string;
    password:string;
    contactNo:string;
    dateOfBirth:Date;
    gender:string;
    wallet:number;
    address:string;

}