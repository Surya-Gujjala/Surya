import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booked-ticket',
  templateUrl: './booked-ticket.component.html',
  styleUrls: ['./booked-ticket.component.css']
})
export class BookedTicketComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
